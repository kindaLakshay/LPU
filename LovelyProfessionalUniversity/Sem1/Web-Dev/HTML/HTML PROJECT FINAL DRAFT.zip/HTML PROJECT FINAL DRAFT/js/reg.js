function validate()
      { var name=document.stopandshop.fname.value;
        var email=document.stopandshop.email.value;
        var mob_no=document.stopandshop.mob_no.value;
        var dob=document.stopandshop.dob.value;
        var Address=document.stopandshop.Address.value;
        var Postalcode=document.stopandshop.Address.value;
        if(fname=null || name=="")
        {
          alert("Name can't be blank");
          return false;
        }
        if(email=null || email=="")
        {
          alert("Please enter your Email");
          return false;
        }
        if(mob_no.length<10)
        {
          alert("Please enter valid Mobile number");
          return false;
        }
        if(dob>=31-12-2022)
        {
          alert("Please select valid dob");
          return false;
        }
        if(Address=null || email=="")
        {
          alert("Please enter your Address");
          return false;
        }
        if(Postalcode=null || Postalcode=="")
        {
          alert("Please enter Pin code")
          return false;
        }
        else
        {
          alert("Registration Successful.")
          return true;
        }
      }